<?php 
    $title = 'CRUD';
    include_once './includes/header.php' // head
?>

<div class="row">
    <div class="col s12 m6 push-m3">
        <h3 class="light">Clientes</h3>
        <table class="striped">
            <thead>
                <tr>
                    <th>Nome:</th>
                    <th>Sobrenome:</th>
                    <th>E_mail:</th>
                    <th>Idade:</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Pedro</td>
                    <td>Teixeira</td>
                    <td>pedrohtpgbi2007@gmail.com</td>
                    <td>25</td>
                    <td><a href="" class="btn-floating green"><i class="material-icons">edit</i></a></td>
                    <td><a href="" class="btn-floating red"><i class="material-icons">delete</i></a></td>
                </tr>
            </tbody>
        </table>
        <br>
        <a href="./adicionar.php" class="btn">Adicionar cliente</a>
    </div>
</div>

<?php 
    include_once './includes/footer.php' // script javascritp - Materialize
?>