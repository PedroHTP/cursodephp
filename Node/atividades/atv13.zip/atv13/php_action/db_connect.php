<?php 
// conexao
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "banco-estudo";

    $connect = mysqli_connect($host, $username, $password, $database);

    if(mysqli_connect_error()) {
        echo "Falha na conexão: ". mysqli_connect_error();
    }