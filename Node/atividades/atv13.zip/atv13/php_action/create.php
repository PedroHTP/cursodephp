<?php
// conexao
require_once './db_connect.php';

    if($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nome = mysqli_escape_string($connect, $_POST['nome']);
        $sobrenome = mysqli_escape_string($connect, $_POST['sobrenome']);
        $email = mysqli_escape_string($connect, $_POST['email']);
        $idade = mysqli_escape_string($connect, $_POST['idade']);

        $comando = "INSERT INTO clientes (nome, sobrenome, email, idade) VALUES ('$nome', '$sobrenome', '$email', '$email', '$idade')";

        if (mysqli_query($connect, $comando)) {
            header('Location: ../index.php?sucesso');
        } else {
            header('Location: index.php?erro');
        }
    }